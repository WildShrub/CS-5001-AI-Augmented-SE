from __future__ import annotations
from dataclasses import dataclass

class BaseLLM:
    def generate(self, prompt: str) -> str:
        raise NotImplementedError

@dataclass
class SimpleHeuristicLLM(BaseLLM):
    """Offline classroom fallback backend."""
    def generate(self, prompt: str) -> str:
        pl = prompt.lower()
        if "pytest" in pl and "test file" in pl:
            return (
                "import pytest\n"
                "from src.program import add, is_even\n\n"
                "def test_add_ints():\n"
                "    assert add(1, 2) == 3\n\n"
                "def test_add_floats():\n"
                "    assert add(0.1, 0.2) == pytest.approx(0.3)\n\n"
                "def test_is_even_true_false():\n"
                "    assert is_even(2) is True\n"
                "    assert is_even(3) is False\n"
            )
        return (
            "def add(a, b):\n"
            "    \"\"\"Return a + b.\"\"\"\n"
            "    return a + b\n\n"
            "def is_even(n: int) -> bool:\n"
            "    \"\"\"Return True if n is even.\"\"\"\n"
            "    return n % 2 == 0\n"
        )

@dataclass
class OllamaLLM(BaseLLM):
    model: str
    host: str = "http://localhost:11434"
    temperature: float = 0.0
    timeout_s: int = 120

    def generate(self, prompt: str) -> str:
        import requests
        url = f"{self.host}/api/generate"
        payload = {"model": self.model, "prompt": prompt, "stream": False, "options": {"temperature": float(self.temperature)}}
        r = requests.post(url, json=payload, timeout=self.timeout_s)
        r.raise_for_status()
        data = r.json()
        return (data.get("response") or "").strip()
