# Classroom CLI Agent (cca)

A small, readable classroom demo agent.

It can:
1) Create a Python program from a user description and save it
2) Create pytest tests for that program
3) Run unit tests + coverage and iterate on tests until 100% line coverage (or max iterations)
4) Commit (and optionally push) using git

## Install
pip install -e .

Optional (live model using Ollama):
pip install -e .[ollama]

## Typical workflow
cca create --repo <repo> --desc "..." --module src/program.py
cca test   --repo <repo> --desc "..." --module src/program.py --tests tests/test_program.py --max-iters 6
cca commit --repo <repo> --message "Agent: add program + tests" --push

## One-shot
cca full --repo <repo> --desc "..." --module src/program.py --tests tests/test_program.py --message "Agent: program + tests" --push

## Notes
- Coverage target: 100% line coverage for the target module only.
- The push step runs `git push` and assumes authentication is already configured.
